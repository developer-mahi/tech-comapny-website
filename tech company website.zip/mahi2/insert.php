<?php 
include('connection.php');
if(isset($_POST["submit"]))
{
	$message=$_POST['message'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$subject=$_POST['subject'];

	//echo=$messages

	$q="INSERT INTO `tauch`( `message`, `name`, `email`, `subject`)
	 VALUES ('[$message]','[$name]','[$email]','[$subject]')";
	$res=mysqli_query($con,$q);
	if($res)
	{
		echo "<script>
		alert('insert')
		</script>";
	}
	else
	{
		echo "not created";
	}
	mysqli_close($con);
}
	

?>