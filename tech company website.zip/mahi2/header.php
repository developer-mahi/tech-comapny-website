<header>
<div class="header-area header-transparent">
<div class="main-header header-sticky">
<div class="container">
<div class="row align-items-center">

<div class="col-xl-2 col-lg-2">
<div class="logo">
<a href="index.php">
    <img src="assets/img/logo/logo2.png" alt=""  ></a>
</div>
</div>
<div class="col-xl-10 col-lg-10">

<div class="main-menu f-right d-none d-lg-block">
<nav>
<ul id="navigation">
<li><a href="index.php">Home</a></li>
<li><a href="about.php">About</a>
</li>
<li><a href="service.php">Service</a></li>
<li><a href="projects.php">Projects</a></li>
<li><a href="contact.php">Contact</a></li>
<li>
<div class="header-right-btn f-right  ml-15 d-none d-xl-inline-block">
<a href="#" class="header-btn">Discuss Your Project<i class="ti-arrow-right"></i> </a>
</div>
</li>
</ul>
</nav>
</div>
</div>

<div class="col-12">
<div class="mobile_menu d-block d-lg-none"></div>
</div>
</div>
</div>
</div>
</div>
</header>