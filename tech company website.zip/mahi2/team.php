<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Event | Template</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="assets/css/A.bootstrap.min.css%2bowl.carousel.min.css%2bslicknav.css%2banimate.min.css%2bmagnific-popup.css%2bfontawesome-all.min.css%2bthemify-icons.css%2bslick.css%2bnice-select.css%2cMcc.ni03m24wq2.css" />
<link rel="stylesheet" href="assets/css/A.style.css.pagespeed.cf.WUK5afKRUO.css">
<script nonce="9953348c-b1ab-4251-8718-ba722723ae97">(function(w,d){!function(a,e,t,r){a.zarazData=a.zarazData||{};a.zarazData.executed=[];a.zaraz={deferred:[],listeners:[]};a.zaraz.q=[];a.zaraz._f=function(e){return function(){var t=Array.prototype.slice.call(arguments);a.zaraz.q.push({m:e,a:t})}};for(const e of["track","set","debug"])a.zaraz[e]=a.zaraz._f(e);a.zaraz.init=()=>{var t=e.getElementsByTagName(r)[0],z=e.createElement(r),n=e.getElementsByTagName("title")[0];n&&(a.zarazData.t=e.getElementsByTagName("title")[0].text);a.zarazData.x=Math.random();a.zarazData.w=a.screen.width;a.zarazData.h=a.screen.height;a.zarazData.j=a.innerHeight;a.zarazData.e=a.innerWidth;a.zarazData.l=a.location.href;a.zarazData.r=e.referrer;a.zarazData.k=a.screen.colorDepth;a.zarazData.n=e.characterSet;a.zarazData.o=(new Date).getTimezoneOffset();a.zarazData.q=[];for(;a.zaraz.q.length;){const e=a.zaraz.q.shift();a.zarazData.q.push(e)}z.defer=!0;for(const e of[localStorage,sessionStorage])Object.keys(e||{}).filter((a=>a.startsWith("_zaraz_"))).forEach((t=>{try{a.zarazData["z_"+t.slice(7)]=JSON.parse(e.getItem(t))}catch{a.zarazData["z_"+t.slice(7)]=e.getItem(t)}}));z.referrerPolicy="origin";z.src="../../cdn-cgi/zaraz/sd0d9.js?z="+btoa(encodeURIComponent(JSON.stringify(a.zarazData)));t.parentNode.insertBefore(z,t)};["complete","interactive"].includes(e.readyState)?zaraz.init():a.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,0,"script");})(window,document);</script></head>
<body class="body-bg">
<?php include('header.php') ?>
<main>

<div class="slider-area">
<div class="single-slider hero-overly slider-height2 slider-bg2 d-flex align-items-center">
<div class="container">
<div class="row justify-content-center ">
<div class="col-xxl-12">

<div class="hero-caption hero-caption2">
<h2>Team Members</h2>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="team-area section-padding">
<div class="container">
<div class="row">
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/15.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Marcus Down</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/11.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Rick Shaw</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/xteam3.jpg.pagespeed.ic.FrA2RWeUY9.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Frank Senbeans</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/xteam4.jpg.pagespeed.ic.2RrGF_yaby.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Marcus Down</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/xteam5.jpg.pagespeed.ic.58kxif95O1.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Marcus Down</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-team mb-40">
<div class="team-img">
<img src="assets/img/gallery/xteam6.jpg.pagespeed.ic.9a9l3XBXtX.jpg" alt="">

<div class="team-social">
<ul>
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-globe"></i></a></li>
</ul>
</div>
</div>
<div class="team-caption">
<h3><a href="#">Marcus Down</a></h3>
<p>Product Designer <span>@Colorlib</span></p>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="about-area bottom-padding">
<div class="container">
<div class="row align-items-center">
<div class="col-xxl-7 col-xl-7 col-lg-6 col-md-8">

<div class="about-img">
<img src="assets/img/2.jpg" alt="">
</div>
</div>
<div class="offset-xxl-1 col-xxl-4 col-xl-5 col-lg-6 col-md-9">
<div class="about-caption">

<div class="section-tittle mb-25">
<h2>A CITYWIDE <span>CELEBRATION <br>OF DESIGN</span></h2>
<p>Dolor sit amet, consectetur adipisicing elit. Commodi, vel omnis repellendus mollitia, explicabo, maiores quisquam numquam quia reiciendis sit, accusantium atque ex animi perspiciatis ab odit earum assumenda aliquid santium atque ex animi.</p>
<p>Dolor sit amet, consectetur adipisicing elit. Commodi, vel omnis repellendus mollitia, explicabo, maiores quisquam numquam quia reiciendis sit, accusantium atque ex animi perspiciatis ab odit earum assumenda aliquid santium atque ex animi.</p>
</div>
</div>
</div>
</div>
</div>
</section>


<div class="map-area">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3570.8289055204555!2d80.27670104937765!3d26.493453183228006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399c38238592b8d7%3A0xa45ee9c66ee0b923!2sRiveyra%20Infotech%20Private%20Limited!5e0!3m2!1sen!2sin!4v1664879551986!5m2!1sen!2sin"
     width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>

</main>
<?php include('footer.php')?>

<div id="back-top">
<a class="wrapper" title="Go to Top" href="#">
<div class="arrows-container">
<div class="arrow arrow-one">
</div>
<div class="arrow arrow-two">
</div>
</div>
</a>
</div>


<script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
<script src="assets/js/popper.min.js%2bbootstrap.min.js.pagespeed.jc.yZEkwMMN5H.js"></script><script>eval(mod_pagespeed_qmzo1NuDrd);</script>
<script>eval(mod_pagespeed_hTv0MWHmPQ);</script>

<script src="assets/js/owl.carousel.min.js%2bslick.min.js.pagespeed.jc.5cEWmZjpOm.js"></script><script>eval(mod_pagespeed_19SuKjGVBe);</script>
<script>eval(mod_pagespeed_G6IB$bWmnu);</script>
<script src="assets/js/jquery.slicknav.min.js%2bwow.min.js%2bjquery.magnific-popup.js%2bjquery.nice-select.min.js%2bjquery.counterup.min.js%2bwaypoints.min.js%2bcontact.js.pagespeed.jc.yfERIWgBqr.js"></script><script>eval(mod_pagespeed_UUIJCUOQK0);</script>

<script>eval(mod_pagespeed_Vc1Aly2E76);</script>
<script>eval(mod_pagespeed_uQnRzp_i_g);</script>
<script>eval(mod_pagespeed_Cy2DQIoKU2);</script>
<script>eval(mod_pagespeed_cKFM9pGZGi);</script>
<script>eval(mod_pagespeed_SqEU6Eb_VG);</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB13ZAvCezMx5TETYIiGlzVIq65Mc2FG5g"></script>

<script>eval(mod_pagespeed_fu26M6kDKZ);</script>
<script src="assets/js/jquery.form.js%2bjquery.validate.min.js%2bmail-script.js%2bjquery.ajaxchimp.min.js%2bplugins.js%2bmain.js.pagespeed.jc.VYsSi9zp6j.js"></script><script>eval(mod_pagespeed_VLUY63rn59);</script>
<script>eval(mod_pagespeed_jD77hBeryA);</script>
<script>eval(mod_pagespeed_yyzKUXhr$M);</script>
<script>eval(mod_pagespeed_rCklr5k7rv);</script>

<script>eval(mod_pagespeed_QTwbuIqO2p);</script>
<script>eval(mod_pagespeed_PR3bwKEudq);</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"75435aafaa4133e4","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.8.1","si":100}' crossorigin="anonymous"></script>
</body>
</html>