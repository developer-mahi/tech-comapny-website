<?php 
$con=mysqli_connect('localhost', 'root','','riveyra')
or die('not connected');
?>