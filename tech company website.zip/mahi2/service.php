<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>SERVICES</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="assets/css/A.bootstrap.min.css%2bowl.carousel.min.css%2bslicknav.css%2banimate.min.css%2bmagnific-popup.css%2bfontawesome-all.min.css%2bthemify-icons.css%2bslick.css%2bnice-select.css%2cMcc.ni03m24wq2.css" />
<link rel="stylesheet" href="assets/css/A.style.css.pagespeed.cf.WUK5afKRUO.css">
<script nonce="abdc21e7-b69c-466a-86e0-7c05f209ca8f">(function(w,d){!function(a,e,t,r){a.zarazData=a.zarazData||{};a.zarazData.executed=[];a.zaraz={deferred:[],listeners:[]};a.zaraz.q=[];a.zaraz._f=function(e){return function(){var t=Array.prototype.slice.call(arguments);a.zaraz.q.push({m:e,a:t})}};for(const e of["track","set","debug"])a.zaraz[e]=a.zaraz._f(e);a.zaraz.init=()=>{var t=e.getElementsByTagName(r)[0],z=e.createElement(r),n=e.getElementsByTagName("title")[0];n&&(a.zarazData.t=e.getElementsByTagName("title")[0].text);a.zarazData.x=Math.random();a.zarazData.w=a.screen.width;a.zarazData.h=a.screen.height;a.zarazData.j=a.innerHeight;a.zarazData.e=a.innerWidth;a.zarazData.l=a.location.href;a.zarazData.r=e.referrer;a.zarazData.k=a.screen.colorDepth;a.zarazData.n=e.characterSet;a.zarazData.o=(new Date).getTimezoneOffset();a.zarazData.q=[];for(;a.zaraz.q.length;){const e=a.zaraz.q.shift();a.zarazData.q.push(e)}z.defer=!0;for(const e of[localStorage,sessionStorage])Object.keys(e||{}).filter((a=>a.startsWith("_zaraz_"))).forEach((t=>{try{a.zarazData["z_"+t.slice(7)]=JSON.parse(e.getItem(t))}catch{a.zarazData["z_"+t.slice(7)]=e.getItem(t)}}));z.referrerPolicy="origin";z.src="../../cdn-cgi/zaraz/sd0d9.js?z="+btoa(encodeURIComponent(JSON.stringify(a.zarazData)));t.parentNode.insertBefore(z,t)};["complete","interactive"].includes(e.readyState)?zaraz.init():a.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,0,"script");})(window,document);</script></head>
<body class="body-bg">
<?php include('header.php')?>
<main>

<div class="slider-area">
<div class="single-slider hero-overly slider-height2 slider-bg2 d-flex align-items-center">
<div class="container">
<div class="row justify-content-center ">
<div class="col-xxl-12">

<div class="hero-caption hero-caption2">
<h2>Service</h2>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="blog_area top-padding">
<div class="container">
<div class="row">
<div class="col-lg-8 mb-5 mb-lg-0">
<div class="blog_left_sidebar">
<article class="blog_item">
<div class="blog_item_img">
<img class="card-img rounded-0" src="assets/img/gallery/22.jpg" alt="">
<a href="#" class="blog_item_date">
<h3>15</h3>
<p>Jan</p>
</a>
</div>
<div class="blog_details">
<a class="d-inline-block" href="blog_details.html">
<h2 class="blog-head" style="color: #fff;">Google inks pact for new 35-storey office</h2>
</a>
<p>That dominion stars lights dominion divide years for fourth have don't stars is that
he earth it first without heaven in place seed it second morning saying.</p>
<ul class="blog-info-link">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
</div>
</article>
<article class="blog_item">
<div class="blog_item_img">
<img class="card-img rounded-0" src="assets/img/gallery/33.jpg" alt="">
<a href="#" class="blog_item_date">
<h3>15</h3>
<p>Jan</p>
</a>
</div>
<div class="blog_details">
<a class="d-inline-block" href="blog_details.html">
<h2 class="blog-head" style="color: #fff;">Google inks pact for new 35-storey office</h2>
</a>
<p>That dominion stars lights dominion divide years for fourth have don't stars is that
he earth it first without heaven in place seed it second morning saying.</p>
<ul class="blog-info-link">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
</div>
</article>
<article class="blog_item">
<div class="blog_item_img">
<img class="card-img rounded-0" src="assets/img/gallery/44.jpg" alt="">
<a href="#" class="blog_item_date">
<h3>15</h3>
<p>Jan</p>
</a>
</div>
<div class="blog_details">
<a class="d-inline-block" href="blog_details.html">
<h2 class="blog-head" style="color: #fff;">Google inks pact for new 35-storey office</h2>
</a>
<p>That dominion stars lights dominion divide years for fourth have don't stars is that
he earth it first without heaven in place seed it second morning saying.</p>
<ul class="blog-info-link">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
</div>
</article>
<article class="blog_item">
<div class="blog_item_img">
<img class="card-img rounded-0" src="assets/img/gallery/55.jpg" alt="">
<a href="#" class="blog_item_date">
<h3>15</h3>
<p>Jan</p>
</a>
</div>
<div class="blog_details">
<a class="d-inline-block" href="blog_details.html">
<h2 class="blog-head" style="color: #fff;">Google inks pact for new 35-storey office</h2>
</a>
<p>That dominion stars lights dominion divide years for fourth have don't stars is that
he earth it first without heaven in place seed it second morning saying.</p>
<ul class="blog-info-link">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
</div>
</article>
<article class="blog_item">
<div class="blog_item_img">
<img class="card-img rounded-0" src="assets/img/gallery/66.jpg" alt="">
<a href="#" class="blog_item_date">
<h3>15</h3>
<p>Jan</p>
</a>
</div>
<div class="blog_details">
<a class="d-inline-block" href="blog_details.html">
<h2 class="blog-head" style="color: #fff;">Google inks pact for new 35-storey office</h2>
</a>
<p>That dominion stars lights dominion divide years for fourth have don't stars is that
he earth it first without heaven in place seed it second morning saying.</p>
<ul class="blog-info-link">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
</div>
</article>
<nav class="blog-pagination justify-content-center d-flex">
<ul class="pagination">
<li class="page-item">
<a href="#" class="page-link" aria-label="Previous">
<i class="ti-angle-left"></i>
</a>
</li>
<li class="page-item">
<a href="#" class="page-link">1</a>
</li>
<li class="page-item active">
<a href="#" class="page-link">2</a>
</li>
<li class="page-item">
<a href="#" class="page-link" aria-label="Next">
<i class="ti-angle-right"></i>
</a>
</li>
</ul>
</nav>
</div>
</div>
<div class="col-lg-4">
<div class="blog_right_sidebar">
<aside class="single_sidebar_widget search_widget">
<form action="#">
<div class="form-group m-0">
<div class="input-group">
<input type="text" class="form-control" placeholder="Search Keyword">
<div class="input-group-append d-flex">
<button class="boxed-btn2" type="button">Search</button>
</div>
</div>
</div>
</form>
</aside>
<aside class="single_sidebar_widget post_category_widget">
<h4 class="widget_title" style="color: #000;">Category</h4>
<ul class="list cat-list">
<li>
<a href="#" class="d-flex">
<p>Web development</p>
<p>(37)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>App development</p>
<p>(10)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Modern technology</p>
<p>(03)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Product</p>
<p>(300)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Online marketing</p>
<p>21</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>E- commerce development</p>
<p>09</p>
</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget popular_post_widget">
<h3 class="widget_title" style="color: #000;">Recent Post</h3>
<div class="media post_item">
<img src="assets/img/post/post_1.jpg" alt="post">
<div class="media-body">
<a href="blog_details.html">
<h3 style="color: #000;">From life was you fish...</h3>
</a>
<p>January 12, 2019</p>
</div>
</div>
<div class="media post_item">
<img src="assets/img/post/post_2.jpg" alt="post">
<div class="media-body">
<a href="blog_details.html">
<h3 style="color: #000;">The Amazing Hubble</h3>
</a>
<p>02 Hours ago</p>
</div>
</div>
<div class="media post_item">
<img src="assets/img/post/post_3.jpg" alt="post">
<div class="media-body">
<a href="blog_details.html">
<h3 style="color: #000;">Astronomy Or Astrology</h3>
</a>
<p>03 Hours ago</p>
</div>
</div>
<div class="media post_item">
<img src="assets/img/post/post_4.jpg" alt="post">
<div class="media-body">
<a href="blog_details.html">
<h3 style="color: #000;">Asteroids telescope</h3>
</a>
<p>01 Hours ago</p>
</div>
</div>
</aside>
<aside class="single_sidebar_widget tag_cloud_widget">
<h4 class="widget_title" style="color: #000;">Tag Clouds</h4>
<ul class="list">
<li>
<a href="#">project</a>
</li>
<li>
<a href="#">love</a>
</li>
<li>
<a href="#">technology</a>
</li>
<li>
<a href="#">travel</a>
</li>
<li>
<a href="#">restaurant</a>
</li>
<li>
<a href="#">life style</a>
</li>
<li>
<a href="#">design</a>
</li>
<li>
<a href="#">illustration</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget instagram_feeds">
<h4 class="widget_title" style="color: #000;">Instagram Feeds</h4>
<ul class="instagram_row flex-wrap">
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_5.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_6.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_7.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_8.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_9.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_10.jpg" alt="">
</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget newsletter_widget">
<h4 class="widget_title" style="color: #000;">Newsletter</h4>
<form action="#">
<div class="form-group">
<input type="email" class="form-control" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email'" placeholder='Enter email' required>
</div>
<button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn" type="submit">Subscribe</button>
</form>
</aside>
</div>
</div>
</div>
</div>
</section>

</main>
<?php include('footer.php') ?>

<div id="back-top">
<a class="wrapper" title="Go to Top" href="#">
<div class="arrows-container">
<div class="arrow arrow-one">
</div>
<div class="arrow arrow-two">
</div>
</div>
</a>
</div>


<script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
<script src="assets/js/popper.min.js%2bbootstrap.min.js.pagespeed.jc.yZEkwMMN5H.js"></script><script>eval(mod_pagespeed_qmzo1NuDrd);</script>
<script>eval(mod_pagespeed_hTv0MWHmPQ);</script>

<script src="assets/js/owl.carousel.min.js%2bslick.min.js.pagespeed.jc.5cEWmZjpOm.js"></script><script>eval(mod_pagespeed_19SuKjGVBe);</script>
<script>eval(mod_pagespeed_G6IB$bWmnu);</script>
<script src="assets/js/jquery.slicknav.min.js%2bwow.min.js%2bjquery.magnific-popup.js%2bjquery.nice-select.min.js%2bjquery.counterup.min.js%2bwaypoints.min.js%2bcontact.js.pagespeed.jc.yfERIWgBqr.js"></script><script>eval(mod_pagespeed_UUIJCUOQK0);</script>

<script>eval(mod_pagespeed_Vc1Aly2E76);</script>
<script>eval(mod_pagespeed_uQnRzp_i_g);</script>
<script>eval(mod_pagespeed_Cy2DQIoKU2);</script>
<script>eval(mod_pagespeed_cKFM9pGZGi);</script>
<script>eval(mod_pagespeed_SqEU6Eb_VG);</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB13ZAvCezMx5TETYIiGlzVIq65Mc2FG5g"></script>

<script>eval(mod_pagespeed_fu26M6kDKZ);</script>
<script src="assets/js/jquery.form.js%2bjquery.validate.min.js%2bmail-script.js%2bjquery.ajaxchimp.min.js%2bplugins.js%2bmain.js.pagespeed.jc.VYsSi9zp6j.js"></script><script>eval(mod_pagespeed_VLUY63rn59);</script>
<script>eval(mod_pagespeed_jD77hBeryA);</script>
<script>eval(mod_pagespeed_yyzKUXhr$M);</script>
<script>eval(mod_pagespeed_rCklr5k7rv);</script>

<script>eval(mod_pagespeed_QTwbuIqO2p);</script>
<script>eval(mod_pagespeed_PR3bwKEudq);</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"75435ab77cbc33ea","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.8.1","si":100}' crossorigin="anonymous"></script>
</body>
</html>