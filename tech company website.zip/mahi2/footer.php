<footer>
<div class="footer-area footer-padding">
<div class="footer-wrapper ">
<div class="container">
<div class="row d-flex justify-content-between">
<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-6">
<div class="single-footer-caption mb-50">
<div class="single-footer-caption mb-30">

<div class="footer-logo mb-25">
<h6><Strong>ADVANTAGE WORK WITH RIVEYRA</Strong> </h6>
</div>
<div class="footer-tittle">
<div class="footer-pera">

<p>Riveyra Infotech supports the thought behind the beginning of a new company and transforming it into an ethnicity, an approach, a chance to convey the best. We are an inventive, successful, well-organized digital firm which is committed and faithful to our customers. By staying focused on our core services we build exceptional and customer-centric websites, engaging the excellent practices for online marketing, receptive web design, web development, and branding.</p>
</div>
</div>

<ul class="footer-social">
<li><a class="fb" href="https://www.facebook.com/RiveyraInfotech/"><i class="fab fa-facebook"></i></a></li>
<li><a class="lnk" href="#"><i class="fab fa-linkedin-in"></i></a></li>
<li><a class="ins" href="https://www.instagram.com/RiveyraInfotech/"><i class="fab fa-instagram"></i></a></li>
</ul>
</div>
</div>
</div>
<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-4 col-sm-5">
<div class="single-footer-caption mb-50">
<div class="footer-tittle">
<h4>Contact Us</h4>
<ul>
<li><a href="#">64,lakhanpur Housing Society Behind Lucy Restaurant,Vikas Nagar,Kanpur</a></li>
<li><a href="#"><span class="__cf_email__" data-cfemail="563f383039163320333822397835393b">sales@riveyrainfotech.com</span></a></li>
<li class="number"><a href="#">099 198 88269</a></li>
</ul>
</div>
</div>
</div>
<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-8 col-sm-11">
<div class="single-footer-caption mb-50">
<div class="footer-tittle">
<h4>Subscribe Newsletter</h4>
<p>raising a heavy fur muff that covered the whole of her lower arm towards the viewer.</p>
</div>

<div class="footer-form">
<div id="mc_embed_signup">
<form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" class="subscribe_form relative mail_part" novalidate>
<input type="email" name="EMAIL" id="newsletter-form-email" placeholder="  Enter your email">
<div class="form-icon">
<button type="submit" name="submit" id="newsletter-submit" class="email_icon newsletter-submit button-contactForm">
Subscribe
</button>
</div>
<div class="mt-10 info"></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>