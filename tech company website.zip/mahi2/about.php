<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>ABOUT</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/A.bootstrap.min.css%2bowl.carousel.min.css%2bslicknav.css%2banimate.min.css%2bmagnific-popup.css%2bfontawesome-all.min.css%2bthemify-icons.css%2bslick.css%2bnice-select.css%2cMcc.ni03m24wq2.css" />
<link rel="stylesheet" href="assets/css/A.style.css.pagespeed.cf.WUK5afKRUO.css">
<script nonce="9009d9fc-c2ae-41bf-8fa5-2ca53db48692">(function(w,d){!function(a,e,t,r){a.zarazData=a.zarazData||{};a.zarazData.executed=[];a.zaraz={deferred:[],listeners:[]};a.zaraz.q=[];a.zaraz._f=function(e){return function(){var t=Array.prototype.slice.call(arguments);a.zaraz.q.push({m:e,a:t})}};for(const e of["track","set","debug"])a.zaraz[e]=a.zaraz._f(e);a.zaraz.init=()=>{var t=e.getElementsByTagName(r)[0],z=e.createElement(r),n=e.getElementsByTagName("title")[0];n&&(a.zarazData.t=e.getElementsByTagName("title")[0].text);a.zarazData.x=Math.random();a.zarazData.w=a.screen.width;a.zarazData.h=a.screen.height;a.zarazData.j=a.innerHeight;a.zarazData.e=a.innerWidth;a.zarazData.l=a.location.href;a.zarazData.r=e.referrer;a.zarazData.k=a.screen.colorDepth;a.zarazData.n=e.characterSet;a.zarazData.o=(new Date).getTimezoneOffset();a.zarazData.q=[];for(;a.zaraz.q.length;){const e=a.zaraz.q.shift();a.zarazData.q.push(e)}z.defer=!0;for(const e of[localStorage,sessionStorage])Object.keys(e||{}).filter((a=>a.startsWith("_zaraz_"))).forEach((t=>{try{a.zarazData["z_"+t.slice(7)]=JSON.parse(e.getItem(t))}catch{a.zarazData["z_"+t.slice(7)]=e.getItem(t)}}));z.referrerPolicy="origin";z.src="../../cdn-cgi/zaraz/sd0d9.js?z="+btoa(encodeURIComponent(JSON.stringify(a.zarazData)));t.parentNode.insertBefore(z,t)};["complete","interactive"].includes(e.readyState)?zaraz.init():a.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,0,"script");})(window,document);</script></head>
<body class="body-bg">
<?php include('header.php') ?>
<main>

<div class="slider-area">
<div class="single-slider hero-overly slider-height2 slider-bg2 d-flex align-items-center">
<div class="container">
<div class="row justify-content-center ">
<div class="col-xxl-12">

<div class="hero-caption hero-caption2">
<h2>About</h2>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="blog_area single-post-area top-padding">
<div class="container">
<div class="row">
<div class="col-lg-8 posts-list">
<div class="single-post">
<div class="feature-img">
<img class="img-fluid" src="assets/img/1.jpg" alt="">
</div>
<div class="blog_details">
<h2 style="color: #fff;">WORK WITH US AND WE PROMISE YOU WON'T BE DISAPPOINTED.
</h2>
<ul class="blog-info-link mt-3 mb-4">
<li><a href="#"><i class="fa fa-user"></i> Travel, Lifestyle</a></li>
<li><a href="#"><i class="fa fa-comments"></i> 03 Comments</a></li>
</ul>
<p class="excert">
We select an appropriate programming framework based on client requirements & develop everything keeping in mind a successful web presence comprising robust architecture, maximum versatility & best scope for future growth. Using object-oriented best practices, comprehensive code base & coding guidelines, our team offers highly customizable solutions to meet the requirements of our clients
</p>
<!--<p>
MCSE boot camps have its supporters and its detractors. Some people do not understand why you
should have to spend money on boot camp when you can get the MCSE study materials yourself at a
fraction of the camp price. However, who has the willpower to actually sit through a
self-imposed MCSE training. who has the willpower to actually
</p>-->
<div class="quote-wrapper">
<div class="quotes">
We believes we are highly qualified to assist and guide you through a comprehensive website overhaul. We combines strategic thinking and emerging technologies to provide innovative solutions that consistently break new ground.
We develops long-term relationships with our clients. We deliver high-quality work through our focus on bidirectional communication, responsive customer service, client education, accurate project management, product quality, and an ethical approach to business. We have a well-documented track record of performing work on budget and on deadline.

</div>
</div>
<p>
As one of the top ten web development companies, we are focused on offering only the best technologies out there in order to help create reliable, secure, and high integrity websites. We not only develop websites and help to update existing websites but will also work with database driven sites, web applications, and corporate internet design and development.
</p>
<!--<p>
MCSE boot camps have its supporters and its detractors. Some people do not understand why you
should have to spend money on boot camp when you can get the MCSE study materials yourself at a
fraction of the camp price. However, who has the willpower to actually sit through a
self-imposed MCSE training. who has the willpower to actually
</p>-->
</div>
</div>
<div class="navigation-top">
<div class="d-sm-flex justify-content-between text-center">
<p class="like-info"><span class="align-middle"><i class="fa fa-heart"></i></span> Lily and 4
people like this</p>
<div class="col-sm-4 text-center my-2 my-sm-0">
</div>
<ul class="social-icons">
<li><a href="https://www.facebook.com/sai4ull"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fab fa-dribbble"></i></a></li>
<li><a href="#"><i class="fab fa-behance"></i></a></li>
</ul>
</div>
<div class="navigation-area">
<div class="row">
<div class="col-lg-6 col-md-6 col-12 nav-left flex-row d-flex justify-content-start align-items-center">
<div class="thumb">
<a href="#">
<img class="img-fluid" src="assets/img/post/preview.jpg" alt="">
</a>
</div>
<div class="arrow">
<a href="#">
<span class="lnr text-white ti-arrow-left"></span>
</a>
</div>
<div class="detials">
<p>Prev Post</p>
<a href="#">
<h4 style="color: #fff;">Space The Final Frontier</h4>
</a>
</div>
</div>
<div class="col-lg-6 col-md-6 col-12 nav-right flex-row d-flex justify-content-end align-items-center">
<div class="detials">
<p>Next Post</p>
<a href="#">
<h4 style="color: #fff;">Telescopes 101</h4>
</a>
</div>
<div class="arrow">
<a href="#">
<span class="lnr text-white ti-arrow-right"></span>
</a>
</div>
<div class="thumb">
<a href="#">
<img class="img-fluid" src="assets/img/post/next.jpg" alt="">
</a>
</div>
</div>
</div>
</div>
</div>
<div class="blog-author">
<div class="media align-items-center">
<img src="assets/img/blog/xauthor.png.pagespeed.ic.qbgj0G74Di.png" alt="">
<div class="media-body">
<a href="#">
<h4>ASHMIX MEDIA AND ADVERTIESEMENT PRIVATE LIMITED</h4>
</a>
<p>I am really happy with your services, it is exceptional, Riveyra Infotech  is just great. When I have a question they answer it at once, they have more than an outstanding customer service. After having a bad experience with my old Web Designer Company, I would say that, Riveyra Infotech  team is  very professional and their knowledge is incredible, they also solve problems very fast, I am impressed. I recommend , Riveyra Infotech to all.</p>
</div>
</div>
</div>
<div class="comments-area">
<h4>05 Comments</h4>
<div class="comment-list">
<div class="single-comment justify-content-between d-flex">
<div class="user justify-content-between d-flex">
<div class="thumb">
<img src="assets/img/blog/xcomment_1.png.pagespeed.ic.JzhIeXwnDW.png" alt="">
</div>
<div class="desc">
<p class="comment">
Multiply sea night grass fourth day sea lesser rule open subdue female fill which them
Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser
</p>
<div class="d-flex justify-content-between">
<div class="d-flex align-items-center">
<h5>
<a href="#">Emilly Blunt</a>
</h5>
<p class="date">December 4, 2017 at 3:12 pm </p>
</div>
<div class="reply-btn">
<a href="#" class="btn-reply text-uppercase">reply</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="comment-list">
<div class="single-comment justify-content-between d-flex">
<div class="user justify-content-between d-flex">
<div class="thumb">
<img src="assets/img/blog/xcomment_2.png.pagespeed.ic.TU34awfC5z.png" alt="">
</div>
<div class="desc">
<p class="comment">
Multiply sea night grass fourth day sea lesser rule open subdue female fill which them
Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser
</p>
<div class="d-flex justify-content-between">
<div class="d-flex align-items-center">
<h5>
<a href="#">Emilly Blunt</a>
</h5>
<p class="date">December 4, 2017 at 3:12 pm </p>
</div>
<div class="reply-btn">
<a href="#" class="btn-reply text-uppercase">reply</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="comment-list">
<div class="single-comment justify-content-between d-flex">
<div class="user justify-content-between d-flex">
<div class="thumb">
<img src="assets/img/blog/xcomment_3.png.pagespeed.ic.VOXdMjiO1T.png" alt="">
</div>
<div class="desc">
<p class="comment">
Multiply sea night grass fourth day sea lesser rule open subdue female fill which them
Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser
</p>
<div class="d-flex justify-content-between">
<div class="d-flex align-items-center">
<h5>
<a href="#">Emilly Blunt</a>
</h5>
<p class="date">December 4, 2017 at 3:12 pm </p>
</div>
<div class="reply-btn">
<a href="#" class="btn-reply text-uppercase">reply</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="comment-form">
<h4>Leave a Reply</h4>
<form class="form-contact comment_form" action="#" id="commentForm">
<div class="row">
<div class="col-12">
<div class="form-group">
<textarea class="form-control w-100" name="comment" id="comment" cols="30" rows="9" placeholder="Write Comment"></textarea>
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<input class="form-control" name="name" id="name" type="text" placeholder="Name">
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<input class="form-control" name="email" id="email" type="email" placeholder="Email">
</div>
</div>
<div class="col-12">
<div class="form-group">
<input class="form-control" name="website" id="website" type="text" placeholder="Website">
</div>
</div>
</div>
<div class="form-group">
<button type="submit" class="button button-contactForm btn_1">Post Comment</button>
</div>
</form>
</div>
</div>
<div class="col-lg-4">
<div class="blog_right_sidebar">
<aside class="single_sidebar_widget search_widget">
<form action="#">
<div class="form-group m-0">
<div class="input-group">
<input type="text" class="form-control" placeholder="Search Keyword">
<div class="input-group-append d-flex">
<button class="boxed-btn2" type="button">Search</button>
</div>
</div>
</div>
</form>
</aside>
<aside class="single_sidebar_widget post_category_widget">
<h4 class="widget_title" style="color: #000;">Category</h4>
<ul class="list cat-list">
<li>
<a href="#" class="d-flex">
<p>Web development</p>
<p>(37)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>App development</p>
<p>(10)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Modern technology</p>
<p>(03)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Product</p>
<p>(300)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>Online marketing</p>
<p>(21)</p>
</a>
</li>
<li>
<a href="#" class="d-flex">
<p>E-commerce development</p>
<p>(21)</p>
</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget popular_post_widget">
<h3 class="widget_title" style="color: #000;">Recent Post</h3>
<div class="media post_item">
<img src="assets/img/up.jpeg" alt="post">
</div>
<div class="media post_item">
<img src="assets/img/ssc.jpeg" alt="post">
</div>
<div class="media post_item">
<img src="assets/img/kkk.jpeg" alt="post">
</aside>
<aside class="single_sidebar_widget tag_cloud_widget">
<h4 class="widget_title" style="color: #000;">Tag Clouds</h4>
<ul class="list">
<li>
<a href="#">project</a>
</li>
<li>
<a href="#">love</a>
</li>
<li>
<a href="#">technology</a>
</li>
<li>
<a href="#">travel</a>
</li>
<li>
<a href="#">restaurant</a>
</li>
<li>
<a href="#">life style</a>
</li>
<li>
<a href="#">design</a>
</li>
<li>
<a href="#">illustration</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget instagram_feeds">
<h4 class="widget_title" style="color: #000;">Instagram Feeds</h4>
<ul class="instagram_row flex-wrap">
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_5.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_6.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_7.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_8.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_9.jpg" alt="">
</a>
</li>
<li>
<a href="#">
<img class="img-fluid" src="assets/img/post/post_10.jpg" alt="">
</a>
</li>
</ul>
</aside>
<aside class="single_sidebar_widget newsletter_widget">
<h4 class="widget_title" style="color: #000;">Newsletter</h4>
<form action="#">
<div class="form-group">
<input type="email" class="form-control" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email'" placeholder='Enter email' required>
</div>
<button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn" type="submit">QUERY</button>
</form>
</aside>
</div>
</div>
</div>
</div>
</section>

</main>
<?php include('footer.php') ?>

<div id="back-top">
<a class="wrapper" title="Go to Top" href="#">
<div class="arrows-container">
<div class="arrow arrow-one">
</div>
<div class="arrow arrow-two">
</div>
</div>
</a>
</div>


<script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
<script src="assets/js/popper.min.js%2bbootstrap.min.js.pagespeed.jc.yZEkwMMN5H.js"></script><script>eval(mod_pagespeed_qmzo1NuDrd);</script>
<script>eval(mod_pagespeed_hTv0MWHmPQ);</script>

<script src="assets/js/owl.carousel.min.js%2bslick.min.js.pagespeed.jc.5cEWmZjpOm.js"></script><script>eval(mod_pagespeed_19SuKjGVBe);</script>
<script>eval(mod_pagespeed_G6IB$bWmnu);</script>
<script src="assets/js/jquery.slicknav.min.js%2bwow.min.js%2bjquery.magnific-popup.js%2bjquery.nice-select.min.js%2bjquery.counterup.min.js%2bwaypoints.min.js%2bcontact.js.pagespeed.jc.yfERIWgBqr.js"></script><script>eval(mod_pagespeed_UUIJCUOQK0);</script>

<script>eval(mod_pagespeed_Vc1Aly2E76);</script>
<script>eval(mod_pagespeed_uQnRzp_i_g);</script>
<script>eval(mod_pagespeed_Cy2DQIoKU2);</script>
<script>eval(mod_pagespeed_cKFM9pGZGi);</script>
<script>eval(mod_pagespeed_SqEU6Eb_VG);</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB13ZAvCezMx5TETYIiGlzVIq65Mc2FG5g"></script>

<script>eval(mod_pagespeed_fu26M6kDKZ);</script>
<script src="assets/js/jquery.form.js%2bjquery.validate.min.js%2bmail-script.js%2bjquery.ajaxchimp.min.js%2bplugins.js%2bmain.js.pagespeed.jc.VYsSi9zp6j.js"></script><script>eval(mod_pagespeed_VLUY63rn59);</script>
<script>eval(mod_pagespeed_jD77hBeryA);</script>
<script>eval(mod_pagespeed_yyzKUXhr$M);</script>
<script>eval(mod_pagespeed_rCklr5k7rv);</script>

<script>eval(mod_pagespeed_QTwbuIqO2p);</script>
<script>eval(mod_pagespeed_PR3bwKEudq);</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"75435abc5bd033e4","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.8.1","si":100}' crossorigin="anonymous"></script>
</body>
</html>